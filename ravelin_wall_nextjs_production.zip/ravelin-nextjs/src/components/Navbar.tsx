"use client";
import React from "react";

export function Navbar() {
  const sections = [
    { href: "#section-sequencer", label: "Sequencer" },
    { href: "#section-telemetry", label: "Telemetry" },
    { href: "#section-workbench", label: "Workbench" },
    { href: "#section-validator", label: "State Check" },
    { href: "#section-tokenomics", label: "Buybacks" },
    { href: "#section-pricing", label: "Pricing" },
    { href: "#section-stack", label: "Docs" },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
        <a href="#section-sequencer" className="flex items-center gap-3">
          <div className="w-9 h-9 bg-blue-900 text-white font-bold text-base flex items-center justify-center border border-blue-700">
            R
          </div>
          <div>
            <span className="font-bold text-base tracking-tight text-slate-900">RAVELIN</span>
            <span className="ml-2 px-2 py-0.5 bg-blue-50 text-blue-800 border border-blue-200 font-mono text-[10px] font-semibold">
              CHAIN 4663
            </span>
          </div>
        </a>

        <nav className="hidden lg:flex items-center gap-2 text-xs">
          {sections.map((s) => (
            <a key={s.href} href={s.href} className="popup-btn px-3.5 py-2">
              {s.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <a href="#section-workbench" className="popup-btn popup-btn-primary px-4 py-2 text-xs">
            Open Workbench
          </a>
        </div>
      </div>
    </header>
  );
}
