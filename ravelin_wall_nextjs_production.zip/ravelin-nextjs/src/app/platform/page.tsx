import React from "react";

export default function PlatformPage() {
  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-10 space-y-8">
      <div className="blue-gradient-box text-white rounded-3xl p-6 sm:p-8 shadow-lg">
        <div className="text-xs font-mono uppercase text-blue-200">ECOSYSTEM &amp; PRICING · /platform</div>
        <h1 className="text-2xl sm:text-3xl font-extrabold mt-1">One Platform for Everything That Trades Here</h1>
      </div>
    </div>
  );
}
