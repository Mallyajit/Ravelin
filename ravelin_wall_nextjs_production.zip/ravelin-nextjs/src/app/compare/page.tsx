import React from "react";

export default function ComparePage() {
  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-10 space-y-8">
      <div className="blue-gradient-box text-white rounded-3xl p-6 sm:p-8 shadow-lg">
        <div className="text-xs font-mono uppercase text-blue-200">LIVE VALIDATOR CHECK · /compare</div>
        <h1 className="text-2xl sm:text-3xl font-extrabold mt-1">WASM State Replay &amp; AWS Nitro PCR0 Verification</h1>
      </div>
    </div>
  );
}
