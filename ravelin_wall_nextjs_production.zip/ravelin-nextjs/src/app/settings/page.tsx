"use client";
import React, { useState } from "react";
import Link from "next/link";

export default function SettingsPage() {
  const [tab, setTab] = useState<"profile" | "apikeys" | "firewall" | "rebates" | "billing">("profile");
  const [name, setName] = useState("Alex Chen");
  const [org, setOrg] = useState("Quantum RWA Fund LP");
  const [budget, setBudget] = useState(500);
  const [cooldown, setCooldown] = useState(60);
  const [rebateWallet, setRebateWallet] = useState("0x71C9a84F2b9011e889A2");
  const [savedNotice, setSavedNotice] = useState<string | null>(null);

  function notify(msg: string) {
    setSavedNotice(msg);
    setTimeout(() => setSavedNotice(null), 3200);
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-12 space-y-8">
      {savedNotice && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white rounded-xl p-4 shadow-2xl text-xs font-mono">
          {savedNotice}
        </div>
      )}

      <div className="flex items-center justify-between border-b border-slate-200 pb-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Account &amp; Enclave Configuration</h1>
          <p className="text-xs text-slate-500 mt-0.5">Edit your profile, RPC keys, firewall rules, rebate payout wallet, and billing tier</p>
        </div>
        <Link href="/" className="popup-btn px-4 py-2 text-xs">
          Back to Main Webpage
        </Link>
      </div>

      <div className="flex flex-wrap gap-2">
        {[
          { id: "profile", label: "Profile & Organization" },
          { id: "apikeys", label: "RPC Keys & Webhooks" },
          { id: "firewall", label: "Firewall & Spend Rules" },
          { id: "rebates", label: "90% Rebate Payout Wallet" },
          { id: "billing", label: "Billing & Plan" },
        ].map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTab(t.id as typeof tab)}
            className={`popup-btn px-4 py-2 text-xs ${tab === t.id ? "is-active" : ""}`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === "profile" && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-4">
          <h2 className="text-lg font-bold text-slate-900">Profile &amp; Organization</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <input value={name} onChange={(e) => setName(e.target.value)} className="px-4 py-3 border border-slate-300 rounded-lg text-sm font-semibold" />
            <input value={org} onChange={(e) => setOrg(e.target.value)} className="px-4 py-3 border border-slate-300 rounded-lg text-sm font-semibold" />
          </div>
          <button type="button" onClick={() => notify("Saved profile and organization settings.")} className="px-7 py-3 rounded-full bg-blue-600 text-white text-xs font-semibold">
            Save Profile Changes
          </button>
        </div>
      )}

      {tab === "firewall" && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-4">
          <h2 className="text-lg font-bold text-slate-900">Firewall &amp; Spend Limits (Zero Sliders)</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <input type="number" value={budget} onChange={(e) => setBudget(Number(e.target.value))} className="px-4 py-3 border border-slate-300 rounded-lg font-mono text-sm font-bold" />
            <input type="number" value={cooldown} onChange={(e) => setCooldown(Number(e.target.value))} className="px-4 py-3 border border-slate-300 rounded-lg font-mono text-sm font-bold" />
          </div>
          <button type="button" onClick={() => notify(`Locked $${budget}/hr cap and ${cooldown}s loop guard in Nitro Enclave.`)} className="px-7 py-3 rounded-full bg-blue-600 text-white text-xs font-semibold">
            Commit Policy to Nitro Enclave
          </button>
        </div>
      )}

      {(tab === "apikeys" || tab === "rebates" || tab === "billing") && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-4">
          <h2 className="text-lg font-bold text-slate-900">Configuration Editor</h2>
          <input value={rebateWallet} onChange={(e) => setRebateWallet(e.target.value)} className="w-full px-4 py-3 border border-slate-300 rounded-lg font-mono text-sm font-bold" />
          <button type="button" onClick={() => notify("Configuration saved to your Ravelin account.")} className="px-7 py-3 rounded-full bg-blue-600 text-white text-xs font-semibold">
            Save Changes
          </button>
        </div>
      )}
    </div>
  );
}
