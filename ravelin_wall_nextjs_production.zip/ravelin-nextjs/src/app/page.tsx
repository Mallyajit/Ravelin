"use client";
import React, { useState } from "react";
import { CoLocationTopology } from "@/components/CoLocationTopology";

export default function HomePage() {
  const [tradeAmt, setTradeAmt] = useState(1500);
  const [budgetCap, setBudgetCap] = useState(500);
  const [cooldownSec, setCooldownSec] = useState(60);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  function notify(msg: string) {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3500);
  }

  return (
    <div className="space-y-20 pb-20">
      {toastMsg && (
        <div className="fixed bottom-5 right-5 z-50 bg-slate-900 text-white border-l-4 border-blue-500 p-4 shadow-2xl text-xs font-mono">
          {toastMsg}
        </div>
      )}

      {/* SECTION A: SEQUENCER & CO-LOCATION */}
      <section id="section-sequencer" className="swiss-grid-bg border-b border-slate-200 pt-10 pb-20 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-3 px-3.5 py-1.5 bg-blue-50 border border-blue-200 text-xs font-mono text-blue-900">
              <span>ROBINHOOD CHAIN MAINNET (ID 4663) | 100 MS BLOCKS</span>
            </div>
            <h1 className="text-4xl sm:text-6xl font-bold tracking-tight text-slate-900 leading-[1.06]">
              One node, in the same place as the chain, close to every block.
            </h1>
            <p className="text-base sm:text-lg text-slate-600 leading-relaxed max-w-2xl">
              Every request is answered from our own hardware-isolated AWS Nitro Enclave node—never a shared upstream. Reverts and AI retry loops are refused at zero gas cost, and 90% of any backrun profit returns to your wallet.
            </p>
            <div className="flex flex-wrap gap-3">
              <a href="#section-workbench" className="popup-btn popup-btn-primary px-6 py-3.5 text-sm">
                Launch Enclave Workbench
              </a>
              <a href="#section-validator" className="popup-btn px-5 py-3.5 text-sm font-mono">
                Inspect State Check
              </a>
            </div>
          </div>
          <div className="lg:col-span-5">
            <CoLocationTopology />
          </div>
        </div>
      </section>

      {/* SECTION B: WORKBENCH */}
      <section id="section-workbench" className="max-w-7xl mx-auto px-4 sm:px-6 space-y-8">
        <div className="bg-blue-900 text-white p-6 sm:p-8 border-l-8 border-sky-400">
          <div className="text-xs font-mono uppercase text-sky-300 font-bold">Zero-Slider Precision Workbench</div>
          <h2 className="text-2xl sm:text-3xl font-bold mt-1">Interactive Enclave Simulator &amp; Firewall Policy</h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="bg-white border-2 border-blue-800 p-6 space-y-4">
            <h3 className="text-lg font-bold text-slate-900">Simulate Robinhood Stock Token Swap</h3>
            <div className="flex gap-2">
              <button type="button" onClick={() => setTradeAmt(Math.max(50, tradeAmt - 250))} className="popup-btn px-3.5 py-2 text-xs font-mono">- $250</button>
              <input type="number" value={tradeAmt} onChange={(e) => setTradeAmt(Number(e.target.value))} className="flex-1 px-3.5 py-2 border-2 border-slate-300 font-mono font-bold" />
              <button type="button" onClick={() => setTradeAmt(tradeAmt + 250)} className="popup-btn px-3.5 py-2 text-xs font-mono">+ $250</button>
            </div>
            <div className="flex flex-wrap gap-2">
              <button type="button" onClick={() => notify(`Swap ($${tradeAmt}) delivered privately in 0.94 ms. Rebate: +$${(tradeAmt * 0.0018).toFixed(2)}`)} className="popup-btn popup-btn-primary px-4 py-2.5 text-xs">
                Simulate Valid Swap
              </button>
              <button type="button" onClick={() => notify(`Refused duplicate AI retry loop (< ${cooldownSec}s) at zero gas cost.`)} className="popup-btn px-4 py-2.5 text-xs border-red-300 text-red-700">
                Simulate AI Retry Loop
              </button>
            </div>
          </div>

          <div className="bg-white border-2 border-blue-800 p-6 space-y-4">
            <h3 className="text-lg font-bold text-slate-900">Precision Spend Cap &amp; Loop Cooldown (No Sliders)</h3>
            <div className="flex flex-wrap gap-2">
              {[100, 500, 1000, 2500].map((v) => (
                <button key={v} type="button" onClick={() => { setBudgetCap(v); notify(`Committed $${v}/hr spend cap to Nitro Enclave.`); }} className={`popup-btn px-3.5 py-2 text-xs font-mono ${budgetCap === v ? "is-active" : ""}`}>
                  ${v}/hr Cap
                </button>
              ))}
            </div>
            <div className="flex flex-wrap gap-2">
              {[15, 60, 120, 300].map((s) => (
                <button key={s} type="button" onClick={() => { setCooldownSec(s); notify(`Set duplicate calldata loop cooldown to ${s} seconds.`); }} className={`popup-btn px-3.5 py-2 text-xs font-mono ${cooldownSec === s ? "is-active" : ""}`}>
                  {s}s Loop Guard
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
