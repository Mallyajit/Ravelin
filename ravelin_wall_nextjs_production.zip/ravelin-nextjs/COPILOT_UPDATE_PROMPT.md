# GitHub Copilot Prompt — 2080 Dark Cyber-Futuristic Argon-4 Redesign + Animated 3D Props, Plasma Buttons & Chart/Hydration Fixes

Copy and paste the entire prompt block below into **GitHub Copilot Chat** (in **Agent** or **Edits** mode in VS Code) to upgrade your Next.js Ravelin Network project to the **2080 Dark Multi-Spectrum Cyber-Futuristic Theme** (`#030712` void cosmos background, neon cyan `#00F0FF`, plasma blue `#3B82F6`, cyber violet `#8B5CF6`, magenta `#EC4899`, and emerald `#10B981`), **2080 typography (`Orbitron` + `Space Grotesk` + `JetBrains Mono`)**, **plasma-laser animated buttons**, **custom-animated 3D floating background props**, **interactive live-executing SDK snippets**, **dark-mode Chart.js graphs**, and **React hydration fixes**:

```markdown
@workspace Upgrade our Next.js Ravelin Network frontend to the 2080 Dark Multi-Spectrum Cyber-Futuristic Argon-4 Benchmark Design (modeled on public/live_preview.html) while fixing the React hydration error and making all 4 Chart.js graphs vibrant in dark mode. Keep all existing content, sections, modals, and subpages intact.

Execute all 7 steps below completely from start to finish:

---

### STEP 1: Load 2080 Futuristic Fonts (`Orbitron`, `Space Grotesk`, `Plus Jakarta Sans`, `JetBrains Mono`)
In `src/app/layout.tsx` (or `<head>`), load Google Fonts:
```html
<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;600;700;800;900&family=Space+Grotesk:wght@500;600;700&family=Bricolage+Grotesque:wght@600;700;800&family=JetBrains+Mono:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet" />
```
Configure `font-display` in `tailwind.config.ts` to use `['"Orbitron"', '"Space Grotesk"', '"Bricolage Grotesque"', 'sans-serif']`.

---

### STEP 2: Fix the React Hydration Error (`"4,89,12,050"` vs `"48,912,050"`)
1. Search all `.tsx` / `.ts` files in `src/` for `.toLocaleString(`.
2. Replace every `.toLocaleString()` with explicit `'en-US'` locale:
   - `item.block.toLocaleString('en-US')`
   - `wasmLatestBlock.toLocaleString('en-US')`
   - `amt.toLocaleString('en-US')`
   - `item.amountUsd.toLocaleString('en-US')`
   - `yr.toLocaleString('en-US', { maximumFractionDigits: 0 })`
3. Add `suppressHydrationWarning` on any dynamic numeric element rendered on initial load.

---

### STEP 3: Apply the 2080 Dark Multi-Spectrum Theme, Plasma-Laser Buttons & Floating Props CSS (`src/app/globals.css`)
Add the 2080 Dark Cyber-Futuristic styles to `src/app/globals.css` (exact CSS available in `public/live_preview.html`):
1. **Deep Cosmos Multi-Spectrum Background**:
   - Base `#030712` with radial nebula gradients in neon cyan (`rgba(0, 240, 255, 0.11)`), cyber violet (`rgba(139, 92, 246, 0.13)`), royal blue (`rgba(59, 130, 246, 0.09)`), emerald (`rgba(16, 185, 129, 0.08)`), and magenta (`rgba(236, 72, 153, 0.08)`).
   - Remap light card surfaces (`bg-white`, `bg-slate-50`) to translucent dark holographic glass (`rgba(10, 18, 40, 0.84)` with `backdrop-filter: blur(16px)` and `border-color: rgba(56, 189, 248, 0.24)`).
   - Apply gradient chromatic text (`linear-gradient(135deg, #FFFFFF 0%, #BAE6FD 38%, #C4B5FD 72%, #6EE7B7 100%)`) to `h1`.
2. **Insanely Animated 2080 Buttons (`.btn-primary-rounded` & `.popup-btn`)**:
   - `.btn-primary-rounded`: Uses `Orbitron`, uppercase tracking, animated multi-color plasma gradient (`#0284C7` → `#2563EB` → `#7C3AED` → `#EC4899` → `#00F0FF`), `neonPulseAura` keyframe glow, diagonal laser shimmer sweep (`::before` with `plasmaSweep`), and magnetic hover lift (`translateY(-3px) scale(1.03)`).
   - `.popup-btn`: Dark tactical glass button (`rgba(12, 21, 46, 0.92)`), cyan/violet holographic sweep on hover (`::before`), glowing multi-spectrum underline bar (`::after`), and neon `.is-active` state.
3. **Multi-Spectrum `.cyber-card` Laser Borders & Screen-Blended Cursor Aura**:
   - `.cyber-card::before` animates a 5-stop neon border (`#00F0FF`, `#3B82F6`, `#8B5CF6`, `#EC4899`, `#10B981`).
   - `#cursorGlowAura` uses `mix-blend-mode: screen` for true neon illumination over dark surfaces, paired with `#cursorReticleRing`.

---

### STEP 4: Add Custom-Animated 3D Background Props (`#bgPropHeroCube`, `#bgPropOrbitalRing`, `#bgPropWasmPoly`, `#bg3dCanvas`)
1. Render the three floating SVG cyber-props in `src/app/page.tsx` with `.cyber-bg-prop`, `.prop-orbit-cw`, and `.prop-orbit-ccw` animations:
   - `#bgPropHeroCube`: Isometric 3D Nitro Enclave reactor cube with dual counter-rotating orbital rings (`NITRO.TEE.01`).
   - `#bgPropOrbitalRing`: Multi-ring 200 ms auction gyroscope & hexagonal shield lattice (`200MS.AUCTION`).
   - `#bgPropWasmPoly`: Rotating WAVM BoLD polyhedron crystal (`WAVM.BOLD.4663`).
2. In `#bg3dCanvas`, render the receding 3D perspective cyber-grid, 36 neural-linked telemetry particles, and 3 rotating 3D wireframe octahedrons in cyan, violet, and emerald that parallax-shift with cursor position.

---

### STEP 5: Upgrade the Interactive SDK Snippet Sandbox (`#sec-docs`) & Animated SVG Circuit Flowcharts
1. In `#sec-docs`, add the `Run Live Snippet` button (`#runLiveSnippetBtn`) and the live enclave JSON-RPC response stream drawer (`#liveSnippetOutputBox`, `#liveSnippetRttBadge`, `#liveSnippetResponseText`) that simulates sub-millisecond Nitro TEE execution (`0.76–0.94 ms`, `90% rebate`, `$0.00 revert gas`) whenever clicked.
2. Keep the 4-node animated SVG circuit flowchart (`#enclaveAnimatedFlowchart`) + 60fps TEE waveform oscilloscope (`#enclaveWaveformCanvas`) in `#sec-workbench`, and the 3-node WAVM replay flowchart in `#sec-statecheck`.

---

### STEP 6: Dark-Mode Chart.js & Holographic Dark Planet Globe (`#globeCanvas`)
1. Update `#globeCanvas` ocean gradient to deep cyber-planet tones (`#0F172A` → `#09132C` → `#030712`) with glowing `#00F0FF` continent dots, `#10B981` North America node, and `#F97316` Europe node.
2. Update all 4 Chart.js instances (`telemetryMainChart`, `validatorLatencyChart`, `buybackCurveChart`, `rebateSplitChart`) to use high-contrast dark-mode styling:
   - Legend labels: `#F8FAFC`, axis ticks: `#94A3B8`, grid lines: `rgba(56, 189, 248, 0.12)`.
   - Dataset colors: Neon Cyan (`#00F0FF`), Royal Blue (`#3B82F6`), Cyber Violet (`#8B5CF6`), Magenta (`#EC4899`), and Emerald (`#10B981`).
   - Always call `Chart.getChart(canvasEl)?.destroy()` before creating a chart instance.

---

### STEP 7: Verify Build
Run `npm run build` to confirm zero TypeScript, ESLint, or hydration errors.
```
